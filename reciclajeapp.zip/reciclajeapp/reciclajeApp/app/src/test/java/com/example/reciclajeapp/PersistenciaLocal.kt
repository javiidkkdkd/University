package com.ejemplo.reciclajeApp // Cambia esto por el nombre de tu paquete

// Clase abstracta: Define el molde para todos los materiales
abstract class MaterialReciclable(
    protected val cantidad: Int // Encapsulamiento: protected
) {
    // Métodos que obligatoriamente deben implementar las hijas
    abstract fun calcularPuntos(): Int
    abstract fun obtenerMensajeImpacto(): String

    // Método común para todos (no necesita override)
    fun getCantidadUnidades(): Int {
        return cantidad
    }
}
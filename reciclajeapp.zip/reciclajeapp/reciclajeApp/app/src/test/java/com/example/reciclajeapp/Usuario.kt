package com.ejemplo.reciclajeApp

class Usuario(val nombre: String) {

    // Encapsulamiento estricto: nadie puede cambiar los puntos manualmente
    private var puntosAcumulados: Int = 0

    // Método para sumar puntos de forma segura
    fun agregarPuntos(puntos: Int) {
        if (puntos > 0) {
            puntosAcumulados += puntos
        }
    }

    // Lógica de Negocio: Determinar el nivel según el puntaje
    fun obtenerNivelActual(): String {
        return when {
            puntosAcumulados < 100 -> "🌱 Reciclador Novato"
            puntosAcumulados < 500 -> "🌿 Guardián del Barrio"
            puntosAcumulados < 1000 -> "🌳 Maestro Ecológico"
            else -> "🌍 Leyenda Verde"
        }
    }

    // Getter para leer los puntos (pero no modificarlos)
    fun getPuntos(): Int {
        return puntosAcumulados
    }
}
package com.ejemplo.reciclajeApp

class LataAluminio(cantidad: Int) : MaterialReciclable(cantidad) {

    override fun calcularPuntos(): Int {
        return cantidad * 30 // 30 puntos por lata (más valioso)
    }

    override fun obtenerMensajeImpacto(): String {
        // Impacto: Ahorro de TV
        val horasTV = cantidad * 3
        return "¡Increíble! Con $cantidad latas, ahorraste la energía de $horasTV horas de televisión."
    }
}
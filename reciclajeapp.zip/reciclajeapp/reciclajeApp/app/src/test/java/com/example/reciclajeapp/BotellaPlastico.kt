package com.ejemplo.reciclajeApp
class BotellaPlastico(cantidad: Int) : MaterialReciclable(cantidad) {

    override fun calcularPuntos(): Int {
        return cantidad * 15 // 15 puntos por cada botella
    }

    override fun obtenerMensajeImpacto(): String {
        // Impacto: Ahorro de luz
        val horasLuz = cantidad * 6
        return "Con estas $cantidad botellas, ahorraste energía para iluminar una habitación por $horasLuz horas."
    }
}
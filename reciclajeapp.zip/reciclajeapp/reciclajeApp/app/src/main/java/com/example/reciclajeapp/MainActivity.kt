package com.ejemplo.reciclajeApp// Asegúrate que este sea tu paquete

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Variables globales para la lógica
    private lateinit var usuario: Usuario
    private lateinit var persistencia: PersistenciaLocal

    // Variables para la interfaz
    private lateinit var tvNivel: TextView
    private lateinit var tvResultado: TextView
    private lateinit var etCantidad: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Inicializar Persistencia y Usuario
        persistencia = PersistenciaLocal(this)
        usuario = persistencia.cargarProgreso()

        // 2. Vincular elementos de la pantalla
        tvNivel = findViewById(R.id.tvNivelUsuario)
        tvResultado = findViewById(R.id.tvResultado)
        etCantidad = findViewById(R.id.etCantidad)

        val btnPlastico = findViewById<Button>(R.id.btnReciclarPlastico)
        val btnAluminio = findViewById<Button>(R.id.btnReciclarAluminio)

        // 3. Mostrar estado inicial
        actualizarPantalla()

        // 4. Configurar Botón Plástico
        btnPlastico.setOnClickListener {
            procesarReciclaje("plastico")
        }

        // 5. Configurar Botón Aluminio
        btnAluminio.setOnClickListener {
            procesarReciclaje("aluminio")
        }
    }

    private fun procesarReciclaje(tipo: String) {
        val cantidadTexto = etCantidad.text.toString()

        // Validación simple: ¿Escribió un número?
        if (cantidadTexto.isEmpty()) {
            Toast.makeText(this, "Ingresa una cantidad primero", Toast.LENGTH_SHORT).show()
            return
        }

        val cantidad = cantidadTexto.toInt()

        // POLIMORFISMO EN ACCIÓN
        // Creamos el objeto específico según el botón presionado
        val material: MaterialReciclable = if (tipo == "plastico") {
            BotellaPlastico(cantidad)
        } else {
            LataAluminio(cantidad)
        }

        // Cálculos
        val puntosGanados = material.calcularPuntos()
        usuario.agregarPuntos(puntosGanados)

        // Guardar datos
        persistencia.guardarProgreso(usuario)

        // Mostrar resultados en pantalla
        tvResultado.text = material.obtenerMensajeImpacto() + "\n\n+ $puntosGanados Puntos"

        // Limpiar campo y actualizar nivel
        etCantidad.text.clear()
        actualizarPantalla()
    }

    private fun actualizarPantalla() {
        tvNivel.text = "Nivel: ${usuario.obtenerNivelActual()} (${usuario.getPuntos()} pts)"
    }
}
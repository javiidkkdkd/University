package com.example.reciclajeapp 
class PapelCarton(cantidad: Int) : MaterialReciclable(cantidad) {
    override fun calcularPuntos() = cantidad * 5
    override fun obtenerMensajeImpacto() = "Salvaste ${cantidad * 10} hojas de papel."
}
package com.example.reciclajeapp

// HERENCIA: Esta es una clase CONCRETA que hereda de la clase abstracta MaterialReciclable.
// Adopta su "forma" pero implementa su propio comportamiento.
class VidrioBotella(cantidad: Int) : MaterialReciclable(cantidad) {

    // POLIMORFISMO: Sobrescribimos el método de la clase padre.
    // El método se llama igual (`calcularPuntos`), pero se comporta de forma distinta
    // para cada tipo de material. El programa decidirá en tiempo de ejecución qué
    // versión de este método usar, dependiendo del objeto (plástico, vidrio, etc.).
    override fun calcularPuntos() = cantidad * 20

    // POLIMORFISMO: Ocurre lo mismo aquí. Cada material genera su propio mensaje.
    override fun obtenerMensajeImpacto() = "Ahorraste ${cantidad * 0.5}kg de arena."
}
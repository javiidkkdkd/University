package com.example.reciclajeapp

// ABSTRACCIÓN: Esta es una clase abstracta. No podemos crear un "MaterialReciclable" genérico.
// Funciona como un CONTRATO o un MOLDE que obliga a todas las clases que hereden de ella
// a tener, como mínimo, los métodos `calcularPuntos` y `obtenerMensajeImpacto`.
// Esto nos asegura que, sin importar el tipo de material que creemos en el futuro,
// siempre sabremos cómo calcular sus puntos y obtener su mensaje.
abstract class MaterialReciclable(protected val cantidad: Int) {

    // MÉTODO ABSTRACTO: No se implementa aquí. Solo se define la "firma".
    // Cada clase hija (BotellaPlastico, LataAluminio, etc.) está OBLIGADA a proporcionar
    // su propia implementación de este método.
    abstract fun calcularPuntos(): Int

    // MÉTODO ABSTRACTO: Igual que el anterior, obliga a las clases hijas a definir
    // cómo se genera su mensaje de impacto específico.
    abstract fun obtenerMensajeImpacto(): String
}
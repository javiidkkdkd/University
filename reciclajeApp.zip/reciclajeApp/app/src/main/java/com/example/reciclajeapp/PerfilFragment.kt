package com.example.reciclajeapp

import android.content.Intent // <-- ¡LA LÍNEA QUE FALTABA!
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import de.hdodenhof.circleimageview.CircleImageView

class PerfilFragment : Fragment() {

    private lateinit var persistencia: PersistenciaLocal
    private lateinit var ivFotoPerfil: CircleImageView
    private lateinit var etNombreUsuario: EditText
    private lateinit var btnCambiarFoto: Button
    private lateinit var btnEditarPerfil: Button
    private lateinit var btnGuardarPerfil: Button

    private val seleccionarImagenLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            try {
                // Persistencia de permisos para la URI
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                requireContext().contentResolver.takePersistableUriPermission(it, takeFlags)
                
                ivFotoPerfil.setImageURI(it)
                persistencia.guardarFotoPerfil(it.toString())
            } catch (e: SecurityException) {
                e.printStackTrace()
                Toast.makeText(requireContext(), "No se pudo acceder a la imagen", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_perfil, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        persistencia = PersistenciaLocal(requireContext())

        inicializarVistas(view)
        cargarDatosPerfil()
        setupListeners()
    }

    private fun inicializarVistas(view: View) {
        ivFotoPerfil = view.findViewById(R.id.ivFotoPerfil)
        etNombreUsuario = view.findViewById(R.id.etNombreUsuario)
        btnCambiarFoto = view.findViewById(R.id.btnCambiarFoto)
        btnEditarPerfil = view.findViewById(R.id.btnEditarPerfil)
        btnGuardarPerfil = view.findViewById(R.id.btnGuardarPerfil)
    }

    private fun cargarDatosPerfil() {
        etNombreUsuario.setText(persistencia.cargarNombreUsuario())
        val fotoUriString = persistencia.cargarFotoPerfil()
        if (fotoUriString.isNotEmpty()) {
            try {
                ivFotoPerfil.setImageURI(Uri.parse(fotoUriString))
            } catch (e: Exception) {
                ivFotoPerfil.setImageResource(R.drawable.ic_perfil)
            }
        }
    }

    private fun setupListeners() {
        btnCambiarFoto.setOnClickListener {
            seleccionarImagenLauncher.launch("image/*")
        }

        btnEditarPerfil.setOnClickListener {
            activarModoEdicion(true)
        }

        btnGuardarPerfil.setOnClickListener {
            val nuevoNombre = etNombreUsuario.text.toString()
            if (nuevoNombre.isNotEmpty()) {
                persistencia.guardarNombreUsuario(nuevoNombre)
                activarModoEdicion(false)
                Toast.makeText(requireContext(), "Perfil guardado", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(requireContext(), "El nombre no puede estar vacío", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun activarModoEdicion(activar: Boolean) {
        etNombreUsuario.isEnabled = activar
        btnCambiarFoto.isEnabled = activar
        btnGuardarPerfil.visibility = if (activar) View.VISIBLE else View.GONE
        btnEditarPerfil.visibility = if (activar) View.GONE else View.VISIBLE
    }
}
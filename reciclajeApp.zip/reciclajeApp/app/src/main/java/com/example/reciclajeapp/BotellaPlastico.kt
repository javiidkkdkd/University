package com.example.reciclajeapp 
class BotellaPlastico(cantidad: Int) : MaterialReciclable(cantidad) {
    override fun calcularPuntos() = cantidad * 15
    override fun obtenerMensajeImpacto() = "Ahorraste energía para ${cantidad * 6} horas de luz."
}
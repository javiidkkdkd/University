package com.example.reciclajeapp 
class LataAluminio(cantidad: Int) : MaterialReciclable(cantidad) {
    override fun calcularPuntos() = cantidad * 30
    override fun obtenerMensajeImpacto() = "Ahorraste energía para ${cantidad * 3} horas de TV."
}
package com.example.reciclajeapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.res.ResourcesCompat
import com.google.android.gms.location.LocationServices
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

class MapaActivity : AppCompatActivity() {
    private lateinit var map: MapView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(applicationContext, PreferenceManager.getDefaultSharedPreferences(applicationContext))
        setContentView(R.layout.activity_mapa)

        map = findViewById(R.id.mapaOsm)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)

        val puntosReciclaje = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableArrayListExtra("PUNTOS_RECICLAJE", CentroReciclaje::class.java)
        } else {
            intent.getParcelableArrayListExtra("PUNTOS_RECICLAJE")
        }

        if (puntosReciclaje != null && puntosReciclaje.isNotEmpty()) {
            cargarMarcadores(puntosReciclaje)
            map.controller.setZoom(14.0)
            map.controller.setCenter(GeoPoint(puntosReciclaje[0].latitud, puntosReciclaje[0].longitud))
        } else {
            map.controller.setZoom(13.0)
            map.controller.setCenter(GeoPoint(-35.428, -71.654)) // Centrado en Talca por defecto
        }

        activarGPS()
    }

    private fun cargarMarcadores(puntos: List<CentroReciclaje>) {
        for (punto in puntos) {
            val marker = Marker(map)
            marker.position = GeoPoint(punto.latitud, punto.longitud)
            marker.title = punto.nombre
            marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            map.overlays.add(marker)
        }
    }

    private fun activarGPS() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            val locationClient = LocationServices.getFusedLocationProviderClient(this)
            locationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    val miUbicacion = GeoPoint(location.latitude, location.longitude)
                    val soyYo = Marker(map)
                    soyYo.position = miUbicacion
                    soyYo.title = "Yo estoy aquí"
                    // ¡CORREGIDO! Usando la forma moderna y segura
                    soyYo.icon = ResourcesCompat.getDrawable(resources, org.osmdroid.library.R.drawable.person, theme)
                    map.overlays.add(soyYo)
                    map.controller.animateTo(miUbicacion)
                }
            }
        }
    }
}
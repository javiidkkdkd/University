package com.example.reciclajeapp 
class VidrioBotella(cantidad: Int) : MaterialReciclable(cantidad) {
    override fun calcularPuntos() = cantidad * 20
    override fun obtenerMensajeImpacto() = "Ahorraste ${cantidad * 0.5}kg de arena."
}
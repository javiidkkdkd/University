package com.example.reciclajeapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import java.util.Locale

class ReciclarFragment : Fragment() {

    private lateinit var usuario: Usuario
    private lateinit var persistencia: PersistenciaLocal
    private lateinit var tvNivel: TextView
    private lateinit var tvResultado: TextView
    private lateinit var tvCentroCercano: TextView
    private lateinit var etCantidad: EditText
    
    private val listaCentros = arrayListOf(
        CentroReciclaje("Jumbo", -35.431725, -71.627516),
        CentroReciclaje("Punto limpio Sodimac", -35.430878, -71.629968),
        CentroReciclaje("CM Reciclaje Carlos Trupp", -35.442953, -71.634760),
        CentroReciclaje("CM Reciclaje Bicentenario", -35.414139, -71.611321),
        CentroReciclaje("Express Lider", -35.429415, -71.646332),
        CentroReciclaje("Reciclaje Lircay spa", -35.399587, -71.634768),
        CentroReciclaje("Centro municipal de reciclaje", -35.397133, -71.651936),
        CentroReciclaje("Residuos", -35.428522, -71.650302),
        CentroReciclaje("Lider Talca", -35.425696, -71.654826),
        CentroReciclaje("Vida Security", -35.424564, -71.661243),
        CentroReciclaje("CM Reciclaje Villas Unidas", -35.415591, -71.646011),
        CentroReciclaje("Recuperadora de Papeles", -35.416288, -71.650908),
        CentroReciclaje("CM Reciclaje Las Colines", -35.448449, -71.656066),
        CentroReciclaje("Reciclajes Peuma Spa", -35.445276, -71.663126),
        CentroReciclaje("Comercial Peuma Spa", -35.447768, -71.664154),
        CentroReciclaje("CM Reciclaje La Florida", -35.439402, -71.680478),
        CentroReciclaje("Reciclean SpA", -35.483955, -71.660420)
    )
    private var nombreCentroMasCercano: String = "Por determinar"

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_reciclar, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        persistencia = PersistenciaLocal(requireContext())
        usuario = persistencia.cargarProgreso()

        inicializarVistas(view)
        setupListeners(view)

        actualizarPantalla()
        verificarPermisosYBuscar()
    }
    
    private fun inicializarVistas(view: View) {
        tvNivel = view.findViewById(R.id.tvNivelUsuario)
        tvResultado = view.findViewById(R.id.tvResultado)
        tvCentroCercano = view.findViewById(R.id.tvCentroCercano)
        etCantidad = view.findViewById(R.id.etCantidad)
    }

    private fun setupListeners(view: View) {
        view.findViewById<Button>(R.id.btnReciclarPlastico).setOnClickListener { procesarReciclaje("plastico") }
        view.findViewById<Button>(R.id.btnReciclarAluminio).setOnClickListener { procesarReciclaje("aluminio") }
        view.findViewById<Button>(R.id.btnReciclarPapel).setOnClickListener { procesarReciclaje("papel") } 
        view.findViewById<Button>(R.id.btnReciclarVidrio).setOnClickListener { procesarReciclaje("vidrio") } 
        
        view.findViewById<Button>(R.id.btnIrMapa).setOnClickListener {
            val intent = Intent(requireContext(), MapaActivity::class.java)
            intent.putParcelableArrayListExtra("PUNTOS_RECICLAJE", listaCentros)
            startActivity(intent)
        }
    }

    private fun verificarPermisosYBuscar() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 100)
        } else {
            obtenerUbicacionYCalcularCercano()
        }
    }

    private fun obtenerUbicacionYCalcularCercano() {
        val locationManager = requireActivity().getSystemService(AppCompatActivity.LOCATION_SERVICE) as LocationManager
        try {
            val location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            
            if (location != null) {
                actualizarUICONCentroCercano(location, listaCentros)
            } else {
                tvCentroCercano.text = "📡 No se pudo obtener la ubicación GPS."
            }
        } catch (e: SecurityException) {
            tvCentroCercano.text = "Error: Se necesitan permisos de GPS."
            e.printStackTrace()
        }
    }
    
    private fun actualizarUICONCentroCercano(miUbicacion: Location, centros: List<CentroReciclaje>) {
        val centroConDistancia = centros
            .map { centro -> Pair(centro, centro.distanciaEnMetros(miUbicacion.latitude, miUbicacion.longitude)) }
            .minByOrNull { it.second }

        if (centroConDistancia != null) {
            val centro = centroConDistancia.first
            val distanciaMetros = centroConDistancia.second
            nombreCentroMasCercano = centro.nombre

            val distanciaKm = distanciaMetros / 1000.0
            val tiempoApieMinutos = (distanciaKm / 4.5) * 60 // Asumiendo 4.5 km/h
            val tiempoEnAutoMinutos = (distanciaKm / 30.0) * 60 // Asumiendo 30 km/h

            val distanciaFormateada = String.format(Locale.US, "%.1f", distanciaKm)
            val tiempoApieFormateado = formatearTiempo(tiempoApieMinutos.toInt())
            val tiempoEnAutoFormateado = formatearTiempo(tiempoEnAutoMinutos.toInt())

            tvCentroCercano.text = "📍 ${centro.nombre} a $distanciaFormateada km\n(🚶${tiempoApieFormateado} | 🚗 ${tiempoEnAutoFormateado})"
        } else {
            tvCentroCercano.text = "🤷‍♂️ No hay puntos de reciclaje en la lista."
        }
    }

    private fun formatearTiempo(minutosTotales: Int): String {
        if (minutosTotales < 1) return "< 1 min"
        val horas = minutosTotales / 60
        val minutos = minutosTotales % 60
        return when {
            horas > 0 -> "${horas}h ${minutos}min"
            else -> "${minutos} min"
        }
    }

    private fun procesarReciclaje(tipo: String) {
        val cantidad = etCantidad.text.toString().toIntOrNull()
        if (cantidad == null || cantidad <= 0) {
            Toast.makeText(requireContext(), "Ingresa cantidad válida", Toast.LENGTH_SHORT).show(); return 
        }
        val material = when (tipo) {
            "plastico" -> BotellaPlastico(cantidad)
            "aluminio" -> LataAluminio(cantidad)
            "papel" -> PapelCarton(cantidad)
            "vidrio" -> VidrioBotella(cantidad)
            else -> throw IllegalArgumentException("Error")
        }
        val puntos = material.calcularPuntos()
        usuario.agregarPuntos(puntos)
        persistencia.guardarProgreso(usuario)

        tvResultado.text = "📍 Entregado en: $nombreCentroMasCercano\n\n${material.obtenerMensajeImpacto()}\n\n🎉 +$puntos Puntos"
        etCantidad.text.clear()
        actualizarPantalla()
    }

    private fun actualizarPantalla() {
        tvNivel.text = "Nivel: ${usuario.obtenerNivelActual()} (${usuario.getPuntos()} pts)"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            obtenerUbicacionYCalcularCercano()
        }
    }
}
package com.example.reciclajeapp 
abstract class MaterialReciclable(protected val cantidad: Int) {
    abstract fun calcularPuntos(): Int
    abstract fun obtenerMensajeImpacto(): String
}
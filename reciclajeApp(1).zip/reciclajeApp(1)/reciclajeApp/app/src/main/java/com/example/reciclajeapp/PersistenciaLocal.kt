package com.example.reciclajeapp 

import android.content.Context
import android.content.SharedPreferences

class PersistenciaLocal(private val context: Context) {
    private val PREFS_NAME = "ReciclajeAppPrefs"
    private val KEY_REGISTRADO = "KEY_USUARIO_REGISTRADO"
    private val KEY_NOMBRE_USUARIO = "KEY_NOMBRE_USUARIO"
    private val KEY_FOTO_PERFIL = "KEY_FOTO_PERFIL"

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun guardarProgreso(usuario: Usuario) {
        prefs.edit().putInt("POINTS", usuario.getPuntos()).apply()
    }

    fun cargarProgreso(): Usuario {
        val nombre = cargarNombreUsuario() // Usamos el nombre de perfil guardado
        val u = Usuario(nombre)
        u.agregarPuntos(prefs.getInt("POINTS", 0))
        return u
    }

    fun estaRegistrado(): Boolean = prefs.getBoolean(KEY_REGISTRADO, false)
    fun guardarEstadoRegistro(v: Boolean) = prefs.edit().putBoolean(KEY_REGISTRADO, v).apply()

    fun guardarNombreUsuario(nombre: String) {
        prefs.edit().putString(KEY_NOMBRE_USUARIO, nombre).apply()
    }

    fun cargarNombreUsuario(): String {
        return prefs.getString(KEY_NOMBRE_USUARIO, "Reciclador Anónimo") ?: "Reciclador Anónimo"
    }

    fun guardarFotoPerfil(uriString: String) {
        prefs.edit().putString(KEY_FOTO_PERFIL, uriString).apply()
    }

    fun cargarFotoPerfil(): String {
        return prefs.getString(KEY_FOTO_PERFIL, "") ?: ""
    }
}
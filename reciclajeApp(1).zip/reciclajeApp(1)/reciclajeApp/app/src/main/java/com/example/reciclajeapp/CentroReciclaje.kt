package com.example.reciclajeapp

import android.location.Location
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class CentroReciclaje(val nombre: String, val latitud: Double, val longitud: Double) : Parcelable {
    fun distanciaEnMetros(latUsuario: Double, lonUsuario: Double): Float {
        val ubicacionUsuario = Location("usuario")
        ubicacionUsuario.latitude = latUsuario
        ubicacionUsuario.longitude = lonUsuario
        
        val ubicacionCentro = Location("centro")
        ubicacionCentro.latitude = latitud
        ubicacionCentro.longitude = longitud
        
        return ubicacionUsuario.distanceTo(ubicacionCentro)
    }
}
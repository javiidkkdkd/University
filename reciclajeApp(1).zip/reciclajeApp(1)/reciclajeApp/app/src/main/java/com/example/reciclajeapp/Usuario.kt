package com.example.reciclajeapp 

class Usuario(val nombre: String) {
    private var puntosAcumulados: Int = 0 
    
    fun agregarPuntos(puntos: Int) { 
        if (puntos > 0) puntosAcumulados += puntos 
    }

    fun obtenerNivelActual(): String {
        return when {
            puntosAcumulados < 50   -> "🐛 Cuncuna Principiante"
            puntosAcumulados < 150  -> "🐞 Chinita de la Suerte"
            puntosAcumulados < 300  -> "🐸 Ranita de Darwin"
            puntosAcumulados < 600  -> "🐦 Picaflor Gigante"
            puntosAcumulados < 1000 -> "🦌 Pudú del Sur"
            puntosAcumulados < 2000 -> "🦊 Zorro Culpeo"
            puntosAcumulados < 3500 -> "🦅 Cóndor Andino"
            puntosAcumulados < 5000 -> "🐆 Puma Patagónico"
            else -> "🐋 Gran Ballena Azul"
        }
    }
    
    fun getPuntos(): Int { return puntosAcumulados }
}